function b() {
  console.log("b");
}

export default b;
