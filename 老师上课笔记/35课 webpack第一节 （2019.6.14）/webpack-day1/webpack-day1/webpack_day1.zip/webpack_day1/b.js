function a() {
  console.log("a");
}

export default a;
