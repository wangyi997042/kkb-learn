

{
  code:0,
  data:{

  },
  message:
  <!-- errors: 具体的报错信息 -->
}
code 0 是成功 其他都是失败
-1 是错误
-666 登录状态过期

<!-- 权限 -->

mongod --dbpath ~/data/db