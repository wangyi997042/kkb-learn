// // const arr = [new Promise(() => {}), new Promise(() => {})];
// // arr.map((item) => {
// //   console.log(item);
// // });
// import React, { Component } from "react";
// import ReactDom from "react-dom";

// class App extends Component {
//   render() {
//     return <div>hello React</div>;
//   }
// }

// ReactDom.render(<App />, document.getElementById("app"));

// const webpack = require("webpack");
// const config = require("../webpack.config.js");

// const compiler = webpack(config);
// Object.keys(compiler.hooks).forEach((hookName) => {
//   compiler.hooks[hookName].tap("xxxx", () => {
//     console.log(`run====> ${hookName}`);
//   });
// });

// compiler.run();
