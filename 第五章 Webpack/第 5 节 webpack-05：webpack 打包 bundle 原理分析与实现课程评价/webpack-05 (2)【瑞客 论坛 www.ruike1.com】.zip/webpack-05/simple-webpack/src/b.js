export const str2 = "kkb";
