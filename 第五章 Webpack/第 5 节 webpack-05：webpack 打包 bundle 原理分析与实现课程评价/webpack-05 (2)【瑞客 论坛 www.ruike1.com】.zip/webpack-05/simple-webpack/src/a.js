export const str = "hanmy";
