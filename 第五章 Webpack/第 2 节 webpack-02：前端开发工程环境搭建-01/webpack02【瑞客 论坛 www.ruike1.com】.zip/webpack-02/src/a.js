export const str = "hello!!!!";
