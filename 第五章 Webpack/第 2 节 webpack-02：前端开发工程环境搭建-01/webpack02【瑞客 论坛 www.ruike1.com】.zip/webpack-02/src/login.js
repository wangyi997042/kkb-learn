import { str } from "./a.js";
console.log("login", str);
